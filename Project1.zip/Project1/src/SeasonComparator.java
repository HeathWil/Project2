import java.util.ArrayList;

/**
 * 
 * ***********Feb 19, 2016**********
 *
 *
 *This class is going to be used if the user decides to search by seasonNumber, 
 *and will search as such.
 */
public class SeasonComparator {
	
	/**
	 * This method is where the comparing by season Number will be done
	 * @param seasonNum, A String representation of the season 
	 * @return int, which will determine whether the season is present or not.
	 */
	public static int compareTo(String seasonNum, ArrayList<TV> tv){
		int i=0;
		
		
		return i;
	}

}
