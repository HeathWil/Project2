import java.util.ArrayList;

/**
 * 
 * *********Feb 19, 2016*********
 * 
 * This class will be used if the user wants to search the library by year released
 *
 */
public class YearComparator {
	
	/**
	 * This method will see if the year the user is looking for is present in the library.
	 * @param year, A String representation of the year
	 * @return int, sharing the information if the year is in the library or not.
	 */
	public int compareTo(String year, ArrayList<Media> library){
		int i=0;
		
		return i;
	}

}
